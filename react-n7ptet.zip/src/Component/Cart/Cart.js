import React, { Component } from "react";
import "./Cart.css";
import { connect } from "react-redux";
import { Link, Switch, BrowserRouter as Router } from "react-router-dom";
import {
  subtractQuantity,
  addQuantity,
  placeOrder,
  description
} from "../../Action/CartAction";

class Cart extends Component {
  constructor(props) {
    super(props);
  }

  pay = () => {
    if (confirm("Confirm to place the orders")) {
      this.props.placeOrder();
      alert("Successfully Placed the orders!!!");
    } else {
      return false;
    }
  }

  login_page_redirect = () => {
    alert("Login to Access your Cart");
    this.props.history.push("/Login");
  }

  addQuantity = id => {
    this.props.addQuantity(id);
  };

  subtractQuantity = id => {
    this.props.subtractQuantity(id);
  };

  description = id => {
    this.props.description(id);
    this.props.history.push("/Description");
  }

  render() {
    return (
      <div className="container" id="card">
        {typeof this.props.user != "undefined" ? (
          <div>
            <h3>My Cart</h3>
            {this.props.cart.length > 0 ? (
              <div>
                <div className="row">
                  <div className="col-sm-4" />
                  <div className="col-sm-4 row">
                    <p>Total : </p>
                    <i className="fa fa-inr" id="rupee" />
                    <h5>{this.props.total}</h5>
                  </div>
                  <div className="col-sm-4">
                    <button
                      onClick={this.pay}
                      className="btn btn-success float-xl-right"
                    >
                      Check Out
                    </button>
                  </div>
                </div>
                <ul>
                  <div className="row">
                    {this.props.cart.map(value => {
                      const product = this.props.products.find(
                        e => e.id === value.id
                      );
                      return (
                        <div className="col-sm-4">
                          <div className="card">
                            <div className="card-body">
                              <h5 className="card-title" onClick={() => this.description(value.id)}>{product.name}</h5>
                              <p className="card-text" />
                              <i className="fa fa-inr" />{" "}
                              {product.properties.price}
                              <button
                                className="btn btn-dark"
                                id="cart_button"
                                onClick={() => this.addQuantity(value.id)}
                              >
                                +
                              </button>
                              <button className="btn btn-dark" id="cart_button">
                                {value.count}
                              </button>
                              <button
                                className="btn btn-dark"
                                id="cart_button"
                                onClick={() => this.subtractQuantity(value.id)}
                                disabled={value.count == 1}
                              >
                                -
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </ul>
              </div>
            ) : (
              <Switch>
                <div className="">
                  No Items in the Cart <Link to="/home">Click here to add</Link>
                </div>
              </Switch>
            )}
          </div>
        ) : (
          <div>{this.login_page_redirect()}</div>
        )}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    products: state.items,
    cart: state.cart,
    user: state.userDetail[0],
    total: state.total
  };
};

const mapDispatchToProps = dispatch => {
  return {
    subtractQuantity: id => {
      dispatch(subtractQuantity(id));
    },
    addQuantity: id => {
      dispatch(addQuantity(id));
    },
    placeOrder: e => {
      dispatch(placeOrder());
    },
    
    description: id => {
      dispatch(description(id));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Cart);
