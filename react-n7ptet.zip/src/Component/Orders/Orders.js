import React, { Component } from "react";
import "./Orders.css";
import { connect } from "react-redux";
import { Link, Switch, BrowserRouter as Router } from "react-router-dom";
import { description } from "../../Action/CartAction";

class Orders extends Component {
  constructor(props) {
    super(props);
  }

  description = id => {
    this.props.description(id);
    this.props.history.push("/Description");
  };

  login_page_redirect = () => {
    alert("Login to Access your Orders");
    this.props.history.push("/Login");
  };

  render() {
    return (
      <div className="container" id="card">
        {typeof this.props.user != "undefined" ? (
          <div>
            <h3>My Orders</h3>
            {this.props.orders.length > 0 ? (
              <div>
                <div className="row">
                  <div className="col-sm-4" />
                  <div className="col-sm-4 row">
                    <p>Total Paid: </p>
                    <i className="fa fa-inr" id="rupee" />
                    <h5>{this.props.total}</h5>
                  </div>
                </div>
                <ul>
                  <div className="row">
                    {this.props.orders.map(value => {
                      const product = this.props.products.find(
                        e => e.id === value.id
                      );
                      return (
                        <div className="col-sm-4">
                          <div className="card">
                            <div className="card-body">
                              <h5 className="card-title"  onClick={() => this.description(product.id)}>{product.name}</h5>
                              <p className="card-text" />
                              Qty : {value.count}
                              <br />
                              <br />
                              <i className="fa fa-inr" />{" "}
                              {product.properties.price}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </ul>
              </div>
            ) : (
              <Switch>
                <div className="">
                  No Items in the Order{" "}
                  <Link to="/home">Click here to Place</Link>
                </div>
              </Switch>
            )}
          </div>
        ) : (
          <div>{this.login_page_redirect()}</div>
        )}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    products: state.items,
    user: state.userDetail[0],
    total: state.total,
    orders: state.orders
  };
};

const mapDispatchToProps = dispatch => {
  return {
    description: id => {
      dispatch(description(id));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Orders);
