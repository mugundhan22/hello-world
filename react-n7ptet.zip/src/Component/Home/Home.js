import React, { Component } from "react";
import { connect } from "react-redux";
import "./Home.css";
import { Redirect } from "react-router-dom";
import { addToList, removeFromList, description } from "../../Action/CartAction";

class Home extends React.Component {
  addElementToCart = id => {
    if (typeof this.props.user != "undefined") {
      this.props.addToList(id);
      alert("You have Successfully added the item in your cart");
      this.props.history.push("/Home");
    } else {
      alert("Login to Add Item");
      this.props.history.push("/Login");
    }
  };

  removeElementToCart = id => {
    this.props.removeFromList(id);
    alert("You have Successfully removed the item in your cart");
    this.props.history.push("/Home");
  };

  description = id => {
    this.props.description(id);
    this.props.history.push("/Description");
  }

  render() {
    return (
      <div className="container" id="card">
        <ul>
          <div className="row">
            {this.props.products.map(value => {
              const eachObject = value;
              let description = eachObject.properties.description;
              return (
                <div className="col-sm-4">
                  <div className="card">
                    <div className="card-body">
                      <h5 className="card-title" onClick={() => this.description(value.id)}>{eachObject.name}</h5>
                      <p className="card-text">
                        <ul>
                          <li>{description[0]}</li>
                        </ul>
                      </p>
                      <i className="fa fa-inr" /> {value.properties.price}
                      <div>
                        {this.props.cart.find(item => item.id === value.id) ? (
                          <button
                            className="btn btn-dark"
                            id="cart_button"
                            onClick={() => this.removeElementToCart(value.id)}
                          >
                            Remove from Cart
                          </button>
                        ) : (
                          <button
                            className="btn btn-dark"
                            id="cart_button"
                            onClick={() => this.addElementToCart(value.id)}
                          >
                            Add to Cart
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </ul>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    products: state.items,
    cart: state.cart,
    user: state.userDetail[0]
  };
};

const mapDispatchToProps = dispatch => {
  return {
    addToList: id => {
      dispatch(addToList(id));
    },
    removeFromList: id => {
      dispatch(removeFromList(id));
    },
    description: id => {
      dispatch(description(id));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Home);
