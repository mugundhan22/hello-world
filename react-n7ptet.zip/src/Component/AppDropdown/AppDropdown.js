import React, { useState } from 'react';
import { connect } from "react-redux";
import { 
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle } 
from 'reactstrap';
import { Link } from 'react-router-dom';
import { LinkContainer } from 'react-router-bootstrap';
import './AppDropdown.css'

class AppDropdown extends React.Component {
   constructor(props) {
    super(props);
      this.state = {
      dropdownOpen : false,
      setDropdownOpen: false
    }
  }

  toggle = () => {
    if(this.state.dropdownOpen === false){
      this.setState({
        dropdownOpen : true,
        setDropdownOpen : true
      });
      return true;
    }
    else{
      this.setState({
        dropdownOpen : false,
        setDropdownOpen : false
      });
      return false;
    }
  };
  
  render(){
  return (
    <Dropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
      <DropdownToggle caret>
      {this.props.user.name} 
      </DropdownToggle>
      <DropdownMenu id="drop">
      <Link to="/Cart">
        <DropdownItem>Cart</DropdownItem>
      </Link>
      <DropdownItem divider/>
      <Link to="/Orders">
        <DropdownItem>My Orders</DropdownItem>
      </Link>
      <DropdownItem divider/>
      <Link to="/Logout">
        <DropdownItem>Logout</DropdownItem>
      </Link>
      </DropdownMenu>
    </Dropdown>
  );
  }
}

const mapStateToProps = state => {
  return {
    user: state.userDetail[0],
  };
};

export default connect(
  mapStateToProps
)(AppDropdown);