import React, { Component } from 'react';
import { render } from 'react-dom';
import { Route, BrowserRouter as Router } from 'react-router-dom';

import Home from '../Home/Home';
import Login from '../Login/Login';
import Footer from '../Footer/Footer';
import Cart from '../Cart/Cart';
import AppRoute from '../../Routing/AppRoute/AppRoute';
import Description from '../Description/Description';
import Orders from '../Orders/Orders';
import Logout from '../Logout/Logout';

class App extends Component {
  render() {
    return (
      <React.Fragment>
        <Router>
          <AppRoute/>
          <Route exact path="/" component= { Home } />
          <Route path="/Home" component= { Home } />
          <Route path="/Cart" component= { Cart } />
          <Route path="/Login" component= { Login } />
          <Route path="/Description" component={Description} />
          <Route path="/Orders" component={Orders} />
          <Route path="/Logout" component={Logout} />
        </Router>
        <Footer/>
      </React.Fragment>
    );
  }
}

export default App;