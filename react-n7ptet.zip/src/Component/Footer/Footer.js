import React from "react";
import './Footer.css';
import { MDBCol, MDBContainer, MDBRow, MDBFooter } from "mdbreact";

const FooterPage = () => {
  return (
    <div className="footer">
      &copy; {new Date().getFullYear()} Copyright: <a href="#"> ATOZ </a>
    </div>
  );
}

export default FooterPage;