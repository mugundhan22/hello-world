import React, { Component } from "react";
import { connect } from "react-redux";
import "./Description.css";
import { Redirect } from "react-router-dom";
import {
  addToList,
  removeFromList,
  description
} from "../../Action/CartAction";

class Description extends React.Component {
  product;
  componentWillMount() {
    this.product = this.props.products.find(item => {
      return item.id === this.props.selected_id;
    });
  }

  route = () => {
    this.props.history.goBack() 
  };

  render() {
    return (
      <div className="container" id="card">
        <div className="card border-dark mb-3">
          <div className="card-header">
            <h2>
              {this.product.name}
              <button
                onClick={e => {
                  this.route();
                }}
                className="btn btn-dark float-xl-right"
                id="back_button"
              >
                <i class="fa fa-arrow-left" aria-hidden="true" /> Back
              </button>
            </h2>
          </div>
          <div className="card-body">
            <h4 className="card-title">
              <i className="fa fa-inr" /> {this.product.properties.price}
            </h4>
            <p className="card-text">
              <ul>
                <h4>Description:</h4>
                {this.product.properties.description.map(value => {
                  return <li id="li">{value}</li>;
                })}
              </ul>
            </p>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    products: state.items,
    cart: state.cart,
    selected_id: state.selected_id,
    user: state.userDetail
  };
};

const mapDispatchToProps = dispatch => {
  return {
    addToList: id => {
      dispatch(addToList(id));
    },
    removeFromList: id => {
      dispatch(removeFromList(id));
    },
    description: id => {
      dispatch(description(id));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Description);
