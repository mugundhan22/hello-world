import React, { Component } from "react";
import { logoutToApplication } from "../../Action/CartAction";
import { connect } from "react-redux";
import { Link, Switch, BrowserRouter as Router } from "react-router-dom";
import "./Logout.css";

class Logout extends Component {
  componentWillMount() {
    this.logoutToApplication();
  }

  logoutToApplication() {
    this.props.logoutToApplication();
  }

  render() {
    return (
      <div className="container" id="content">
        <h3>You have been Successfully Logged Out</h3>
        <button className="btn btn-primary">
          <Link to="/login" id="but">
            Login
          </Link>
        </button>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    logoutToApplication: e => {
      dispatch(logoutToApplication());
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Logout);
