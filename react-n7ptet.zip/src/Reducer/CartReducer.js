import { ADD_USER,
  ADD_TO_LIST,
  REMOVE_TO_LIST,
  SUB_QUANTITY,
  ADD_QUANTITY,
  LOGOUT_TO_APPLICATION,
  PLACE_ORDER,
  DESCRIPTION
  } from '../Action/Type/type.js';

let initialState = {
   "selected_id": '',
  "orders": [

  ],
  "cart": [
  ],
   "items": [
    {
      "id": "1",
      "name": "Apple iPhone XR",
      "properties": {
        "description": [
          "6.1-inch Liquid Retina display (LCD)",
          "IP67 water and dust resistant (maximum depth of 1 meter up to 30 minutes)",
          "12MP camera with OIS and 7MP TrueDepth front camera—Portrait mode, Portrait Lighting, Depth Control, and Smart HDR"
        ],
        "price": "47900"
      }
    },
    {
      "id": "2",
      "name": "Redmi Note 8 Pro",
      "properties": {
        "description": [
          "64MP AI Quad rear camera with portrait, ultra-wide lens, macro lens, LED flash, AI support | 20MP front camera",
          "Performance: Smooth gaming experience with powerful Helio G90T gaming processor",
          "16.58 centimeters (6.53-inch) Dot Notch HDR Display with 2340 x 1080 pixels resolution and 19.5:9 aspect ratio"
        ],
        "price": "14999"
      }
    },
    {
      "id": "3",
      "name": "Samsung M30s",
      "properties": {
        "description": [
          "48MP + 8MP + 5MP triple rear camera | 16MP front facing camera",
          "16.21 centimeters (6.4-inch) FHD+ capacitive touchscreen with 2340 x 1080 pixels resolution 16M color support",
          "Memory, Storage & SIM: 4GB RAM | 64GB storage expandable up to 512GB | Dual nano SIM with dual standby (4G+4G)"
        ],
        "price": "13999"
      }
    },
    {
      "id": "4",
      "name": "Vivo V15 Pro",
      "properties": {
        "description": [
          "16.23cm(6.39) FHD+ Ultra Fullview Super AMOLED display with 19.5:9 aspect ratio and 91.64%Screen to body ratio",
          "In-display Fingerprint Scanning ; Dual-Engine Fast Charging ; Bluetooth: 5.0V",
          "Pop-Up Selfie Camera: 32MP Pop-Up Selfie Camera with AI Face Beauty, AI portrait composition,Bokeh Mode, AI body Shaping"
        ],
        "price": "19999"
      }
    },
    {
      "id": "5",
      "name": "Realme 5 Pro",
      "properties": {
        "description": [
          "Powered by a 10 nm octa-core Qualcomm Snapdragon 712 AIE processor",
          "Camera: 48 MP AI Quad Camera",
          "Display: 16 cm (6.3) FHD+ Mini-drop display"
        ],
        "price": "13475"
      }
    }
  ],
  "userDetail": [ 
  ],
  "total" : 0
}
const cart_reducers = (state = initialState, action) => {
  //INSIDE HOME COMPONENT
  if (action.type === ADD_USER) {
    console.log('Current state',state);
    state.userDetail.push({name:"Balamurugan",email:action.userName, password:action.password});
    console.log('Updated state',state);
      return {
        ...state,
      }
  }
  if(action.type === ADD_TO_LIST ){
    const addedItem = {
      "id": action.id,
      "count": 1
    }
    index = state.items.findIndex(e => e.id === action.id);
    state.total += parseInt(state.items[index].properties.price);
    state.cart.push(addedItem);
    return{
      ...state
    }
  }
  if(action.type === REMOVE_TO_LIST){
    let index = state.cart.findIndex(list => list.id === action.id);
    state.cart.splice(index,1);
    return{
      ...state
    }
  }

  if(action.type === ADD_QUANTITY){
    let index = state.cart.findIndex(list => list.id === action.id);
    state.cart[index].count += 1;
    
    let product_index = state.items.findIndex(e => e.id === action.id);
    state.total += parseInt(state.items[product_index].properties.price);
    return{
      ...state
    }
  }

  if(action.type === SUB_QUANTITY){
    let index = state.cart.findIndex(list => list.id === action.id);
    state.cart[index].count -= 1;
    let product_index = state.items.findIndex(e => e.id === action.id);
    state.total -= parseInt(state.items[product_index].properties.price);
    return{
      ...state
    }
  }

  if(action.type === LOGOUT_TO_APPLICATION){
    state.userDetail = [];
    return{
      ...state
    }
  }

  if(action.type === PLACE_ORDER ){
    state.cart.forEach(value => {
      state.orders.push(value)
    })
    state.cart = [];
    return{
      ...state
    }
  }

  if(action.type === DESCRIPTION ){
    state.selected_id = action.id;
    return{
      ...state
    }
  }


  else{
    return state;
  }
}

export default cart_reducers;