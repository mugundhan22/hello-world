import {
  ADD_TO_LIST,
  REMOVE_TO_LIST,
  SUB_QUANTITY,
  ADD_QUANTITY,
  LOGOUT_TO_APPLICATION,
  ADD_USER,
  PLACE_ORDER,
  DESCRIPTION
} from "./Type/type.js";

export const addToList = (id) => {
  return{
    type: ADD_TO_LIST,
    id
  }
}

export const removeFromList = (id) => {
  return{
    type: REMOVE_TO_LIST,
    id
  }
}

export const addQuantity = (id) => {
  return{
    type: ADD_QUANTITY,
    id
  }
}

export const subtractQuantity = (id) => {
  return{
    type: SUB_QUANTITY,
    id
  }
}

export const logoutToApplication = () => {
  return{
    type: LOGOUT_TO_APPLICATION
  }
}

export const addUser = (userName, password) => {
  return{
    type: ADD_USER,
    userName, 
    password
  }
}

export const description = (id) => {
  return{
    type: DESCRIPTION,
    id
  }
}

export const placeOrder = () => {
  return{
    type: PLACE_ORDER
  }
}