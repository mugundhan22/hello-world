import React, { Component } from 'react';
import { render } from 'react-dom';
import './style.css';
import 'bootstrap/dist/css/bootstrap.css';
import { Provider } from 'react-redux';
import { createStore } from 'redux';

import App from './Component/App/App'
import CartReducer from './Reducer/CartReducer';

const store = createStore(CartReducer);
  
render(
  <Provider store={store}>
    <App/>
  </Provider>, document.getElementById("root")
);
