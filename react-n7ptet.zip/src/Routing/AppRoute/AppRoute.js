import React, { Component } from 'react';
import { render } from 'react-dom';
import { Link, Switch } from 'react-router-dom';
import { Fragment } from 'react';
import { Glyphicon } from 'react-bootstrap'
import { connect } from "react-redux";
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
} from 'reactstrap';

import './AppRoute.css'
import AppDropdown from '../../Component/AppDropdown/AppDropdown'
import Login from '../../Component/Login/Login';
import Home from '../../Component/Home/Home';
import Cart from '../../Component/Cart/Cart';
import About from '../../Component/About/About';
import ContactUs from '../../Component/ContactUs/ContactUs';

class AppRoute extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isOpen: false,
    };
    this.toggle = this.toggle.bind(this);
  }

  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }

  render(){
    console.log('Approute Rerenders',this.props);
    console.log('Type of username',typeof this.props.userName);
    return(
      <Switch>
      <Fragment>
        <Navbar color="dark" dark expand="md"> 
            <NavbarBrand href="/">
              ATOZ Shopping
            </NavbarBrand>
            <NavbarToggler onClick={this.toggle} />
            <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>
            <NavItem className="d-flex align-items-center">
              <NavLink tag={Link} to="/Home" className="font-weight-bold">
                Home
              </NavLink>
            </NavItem>
            {typeof this.props.userName === "undefined" ? (
            <NavItem className="d-flex align-items-center">
              <NavLink tag={Link} to="/Login" className="font-weight-bold">
                Login
              </NavLink>
            </NavItem>
            ):(
              <AppDropdown/>
            )}
            </Nav>
            </Collapse>
        </Navbar>
        </Fragment>
        </Switch>
    );
  }
}

const mapStateToProps = state => {
  return {
    userName: state.userDetail[0]
  };
};

export default connect(
  mapStateToProps)(AppRoute);